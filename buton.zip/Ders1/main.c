#include <main.h>




void main()
{
   set_tris_b(0x00);
   set_tris_a(0xff);
   output_b(0x00);
   int a=0;
   while(TRUE)
   {
      if(input(pin_A1)==1){
      delay_ms(100);
         if(input(pin_A1)==0){
            a++;
         }
      }
      if(a==5){
         output_high(pin_B4);
      }
   }
}
