#include <16F84A.h>

#FUSES NOWDT                    //No Watch Dog Timer

#use delay(crystal=4000000)

